## Json Server

- create a json-server folder
- https://github.com/typicode/json-server


### Installation 

- `npm install json-server`


## create db.jsone file and add data 


### run server

- `npx json-server db.json`