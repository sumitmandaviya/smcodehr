import axios from "axios";
import React, { useEffect, useState } from "react";

const App = () => {
  const [users, setUsers] = useState([]);
  const [body, setBody] = useState("");
  const [title, setTitle] = useState("");
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const res = await axios.get("http://localhost:3000/posts");
    setUsers(res.data); 
  };

  const handleSubmit = () => {
    if (!title || !body) return alert("Title and Body required");

    const newPost = {
      id: editId || users.length + 1,
      title,
      body,
    };

    if (editId) {
      setUsers(
        users.map((u) => (u.id === editId ? newPost : u))
      );
      setEditId(null);
    } else {
      setUsers([...users, newPost]);
    }

    setTitle("");
    setBody("");
  };

  const handleDelete = (id) => {
    setUsers(users.filter((u) => u.id !== id));
  };

  const handleEdit = (post) => {
    setTitle(post.title);
    setBody(post.body);
    setEditId(post.id);
  };

  return (
    <>
      <div className="flex flex-col items-center gap-4 mt-4">
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-[500px] m-2 p-2 border border-gray-300 rounded"
        />
        <input
          type="text"
          placeholder="Body"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          className="w-[500px] m-2 p-2 border border-gray-300 rounded"
        />
        <button
          onClick={handleSubmit}
          className="bg-green-500 text-white w-[500px] p-2 rounded hover:bg-green-600 transition"
        >
          {editId ? "UPDATE" : "SUBMIT"}
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4 m-4 p-4">
        {users.map((u) => (
          <div
            key={u.id}
            className="bg-white shadow-md p-4 rounded border border-gray-200"
          >
            <p className="text-sm text-gray-500">ID: {u.id}</p>
            <h3 className="font-bold text-lg">{u.title}</h3>
            <p className="text-gray-700">{u.body}</p>
            <div className="flex gap-2 mt-4">
              <button
                onClick={() => handleEdit(u)}
                className="bg-blue-500 text-white px-4 py-1 rounded hover:bg-blue-600"
              >
                Edit
              </button>
              <button
                onClick={() => handleDelete(u.id)}
                className="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default App;
